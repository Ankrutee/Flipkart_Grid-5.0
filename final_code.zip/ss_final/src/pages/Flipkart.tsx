import { FunctionComponent } from "react";
import React from 'react';
import { useEffect, useState } from "react";
import { ethers } from "ethers";
import { MetaMaskInpageProvider } from "@metamask/providers";

import abi from "../coinABI/SAL.json";


const contractAddress = "0xA1836432b505C18C844cEf564026009B00Fd66B7";
const contractABI = abi;

// const connectWallet = async (e) => {
//   try {
//     e.preventDefault();
//     const { ethereum } = window;

//     if (!ethereum) {
//       alert("Get MetaMask!");
//       return;
//     }

//     const accounts = await ethereum.request({ method: "eth_requestAccounts" });

//     console.log("Connected", accounts[0]);

//     const provider = new ethers.Web3Provider(ethereum);
//     const signer = provider.getSigner();
//     const SALContract = new ethers.Contract(contractAddress, contractABI, signer);
//     await SALContract.newAccount(accounts[0]);
//     let userCoins = await SALContract.getBalance(accounts[0]);
//     console.log("coins:", userCoins.toNumber());
//     console.log("Button clicked! Action performed.");
//   } catch (error) {

//     console.log(error)
//   }
// }
declare global {
  interface Window{
    ethereum?:MetaMaskInpageProvider
  }
}
async function addToCartFunction() {


  const { ethereum } = window;

  if (!ethereum) {
    alert("Get MetaMask!");
    return;
  }

  const accounts = await ethereum.request({ method: "eth_requestAccounts" });

  console.log("Connected", accounts[0]);

  const provider = new ethers.BrowserProvider(ethereum);
  const signer = provider.getSigner();
  const SALContract = new ethers.Contract(contractAddress, contractABI, signer);
  await SALContract.newAccount(accounts[0]);
  let userCoins = await SALContract.getBalance(accounts[0]);
  console.log("coins:", userCoins.toNumber());

  // const accounts = ethereum.request({ method: "eth_requestAccounts" });

  // console.log("Connected", accounts[0]);

  // const provider = new ethers.providers.Web3Provider(ethereum);
  // const signer = provider.getSigner();
  // const SALContract = new ethers.Contract(contractAddress, contractABI, signer);
  // SALContract.newAccount(accounts[0]);
  // let userCoins = SALContract.getBalance(accounts[0]);
  // console.log("coins:", userCoins.toNumber());
  // console.log("Button clicked! Action performed.");


}


const Flipkart: FunctionComponent = () => {
  return (
    <div className="relative bg-whitesmoke-100 w-full h-[3894.02px] text-left text-base text-darkgray font-roboto">
      <div className="absolute top-[0px] left-[0px] w-[1920px] h-[3894.02px] font-poppins">
        <div className="absolute w-full top-[53px] right-[0px] left-[0px] bg-royalblue shadow-[0px_2px_2.5px_rgba(0,_0,_0,_0.3)] h-[3px]" />
        <div className="absolute w-full top-[45px] right-[0px] left-[0px] bg-white h-[112.59px] text-center text-sm text-gray-300 font-roboto">
          <div className="absolute w-full top-[0px] right-[0px] left-[0px] bg-white shadow-[0px_1px_1px_rgba(0,_0,_0,_0.16)] h-[112.59px]">
            <div className="absolute top-[calc(50%_-_41.29px)] left-[calc(50%_-_664px)] w-[1280px] h-[112.59px]">
              <div className="absolute top-[12px] left-[calc(50%_-_618px)] flex flex-row pt-[67px] pb-[0.589996337890625px] pr-[6.949999809265137px] pl-[7.050000190734863px] items-start justify-start">
                <img
                  className="absolute my-0 mx-[!important] h-[calc(100%_-_23.59px)] w-full top-[0px] right-[0px] bottom-[23.59px] left-[0px] max-w-full overflow-hidden max-h-full object-cover z-[0]"
                  alt=""
                  src="/29327f40e9c4d26bpng@2x.png"
                />
                <div className="relative leading-[19.6px] font-medium z-[1]">
                  Grocery
                </div>
              </div>
              <div className="absolute top-[12px] left-[calc(50%_-_502.31px)] flex flex-row pt-[67px] pb-[0.589996337890625px] pr-[7.5px] pl-[6.5px] items-start justify-start">
                <img
                  className="absolute my-0 mx-[!important] h-[calc(100%_-_23.59px)] w-full top-[0px] right-[0px] bottom-[23.59px] left-[0px] max-w-full overflow-hidden max-h-full object-cover z-[0]"
                  alt=""
                  src="/22fddf3c7da4c4f4png@2x.png"
                />
                <div className="relative leading-[19.6px] font-medium z-[1]">
                  Mobiles
                </div>
              </div>
              <div className="absolute top-[12px] left-[calc(50%_-_386.62px)] flex flex-row pt-[68px] pb-0 pr-[1.339999794960022px] pl-[1.3200000524520874px] items-start justify-start">
                <img
                  className="absolute my-0 mx-[!important] h-[calc(100%_-_24.59px)] w-full top-[0px] right-[0px] bottom-[24.59px] left-[0px] max-w-full overflow-hidden max-h-full object-cover z-[0]"
                  alt=""
                  src="/0d75b34f7d8fbcb3png@2x.png"
                />
                <div className="relative w-[61.34px] h-[20.59px] z-[1]">
                  <div className="absolute top-[0px] left-[-1px] leading-[19.6px] font-medium">
                    Fashion
                  </div>
                  <img
                    className="absolute top-[8.5px] left-[calc(50%_+_24.18px)] w-2 h-[5px] overflow-hidden"
                    alt=""
                    src="/svg.svg"
                  />
                </div>
              </div>
              <div className="absolute top-[12px] left-[calc(50%_-_270.94px)] flex flex-row pt-[68px] px-0 pb-0 items-start justify-start">
                <img
                  className="absolute my-0 mx-[!important] h-[calc(100%_-_24.59px)] w-[calc(100%_-_17.13px)] top-[0px] right-[8.56px] bottom-[24.59px] left-[8.57px] max-w-full overflow-hidden max-h-full object-cover z-[0]"
                  alt=""
                  src="/69c6589653afdb9apng@2x.png"
                />
                <div className="relative w-[81.13px] h-[20.59px] z-[1]">
                  <div className="absolute top-[0px] left-[-1px] leading-[19.6px] font-medium">
                    Electronics
                  </div>
                  <img
                    className="absolute top-[8.5px] left-[calc(50%_+_34.06px)] w-2 h-[5px] overflow-hidden"
                    alt=""
                    src="/svg1.svg"
                  />
                </div>
              </div>
              <div className="absolute top-[12px] left-[calc(50%_-_138.12px)] flex flex-row pt-[68px] pb-0 pr-[7.0799994468688965px] pl-[7.059999942779541px] items-start justify-start">
                <img
                  className="absolute my-0 mx-[!important] h-[calc(100%_-_24.59px)] w-full top-[0px] right-[0px] bottom-[24.59px] left-[0px] max-w-full overflow-hidden max-h-full object-cover z-[0]"
                  alt=""
                  src="/ab7e2b022a4587ddjpg@2x.png"
                />
                <div className="relative w-[49.86px] h-[20.59px] z-[1]">
                  <div className="absolute top-[0px] left-[-1px] leading-[19.6px] font-medium">
                    Home
                  </div>
                  <img
                    className="absolute top-[8.5px] left-[calc(50%_+_18.43px)] w-2 h-[5px] overflow-hidden"
                    alt=""
                    src="/svg2.svg"
                  />
                </div>
              </div>
              <div className="absolute top-[12px] left-[calc(50%_-_23.44px)] flex flex-row pt-[67px] px-0 pb-[0.589996337890625px] items-start justify-start">
                <img
                  className="absolute my-0 mx-[!important] h-[calc(100%_-_23.59px)] w-[calc(100%_-_6px)] top-[0px] right-[3.04px] bottom-[23.59px] left-[2.96px] max-w-full overflow-hidden max-h-full object-cover z-[0]"
                  alt=""
                  src="/0ff199d1bd27eb98png@2x.png"
                />
                <div className="relative leading-[19.6px] font-medium z-[1]">
                  Appliances
                </div>
              </div>
              <div className="absolute top-[12px] left-[calc(50%_+_97.16px)] flex flex-row pt-[67px] pb-[0.589996337890625px] pr-[11.6899995803833px] pl-[13.3100004196167px] items-start justify-start">
                <img
                  className="absolute my-0 mx-[!important] h-[calc(100%_-_23.59px)] w-full top-[0px] right-[0px] bottom-[23.59px] left-[0px] max-w-full overflow-hidden max-h-full object-cover z-[0]"
                  alt=""
                  src="/71050627a56b4693png@2x.png"
                />
                <div className="relative leading-[19.6px] font-medium z-[1]">
                  Travel
                </div>
              </div>
              <div className="absolute top-[12px] left-[calc(50%_+_212.84px)] flex flex-row pt-[67px] px-0 pb-[0.589996337890625px] items-start justify-start">
                <img
                  className="absolute my-0 mx-[!important] h-[calc(100%_-_23.59px)] w-[calc(100%_-_2px)] top-[0px] right-[1.93px] bottom-[23.59px] left-[0.07px] max-w-full overflow-hidden max-h-full object-cover z-[0]"
                  alt=""
                  src="/f15c02bfeb02d15dpng@2x.png"
                />
                <div className="relative leading-[19.6px] font-medium z-[1]">
                  Top Offers
                </div>
              </div>
              <div className="absolute top-[12px] left-[calc(50%_+_328.66px)] flex flex-row pt-[68px] px-0 pb-0 items-start justify-start">
                <img
                  className="absolute my-0 mx-[!important] h-[calc(100%_-_24.59px)] w-[calc(100%_-_72px)] top-[0px] right-[36px] bottom-[24.59px] left-[36px] max-w-full overflow-hidden max-h-full object-cover z-[0]"
                  alt=""
                  src="/dff3f7adcf3a90c6png@2x.png"
                />
                <div className="relative w-[136px] h-[20.59px] z-[1]">
                  <div className="absolute top-[0px] left-[0px] leading-[19.6px] font-medium">{`Beauty, Toys & More`}</div>
                  <img
                    className="absolute top-[8.5px] left-[calc(50%_+_61.5px)] w-2 h-[5px] overflow-hidden"
                    alt=""
                    src="/svg3.svg"
                  />
                </div>
              </div>
              <div className="absolute top-[12px] left-[calc(50%_+_516.34px)] flex flex-row pt-[68px] px-0 pb-0 items-start justify-start">
                <img
                  className="absolute my-0 mx-[!important] h-[calc(100%_-_24.59px)] w-[calc(100%_-_35.58px)] top-[0px] right-[17.79px] bottom-[24.59px] left-[17.79px] max-w-full overflow-hidden max-h-full object-cover z-[0]"
                  alt=""
                  src="/05d708653beff580png@2x.png"
                />
                <div className="relative w-[99.58px] h-[20.59px] z-[1]">
                  <div className="absolute top-[0px] left-[0px] leading-[19.6px] font-medium">
                    Two Wheelers
                  </div>
                  <img
                    className="absolute top-[8.5px] left-[calc(50%_+_43.29px)] w-2 h-[5px] overflow-hidden"
                    alt=""
                    src="/svg4.svg"
                  />
                </div>
              </div>
            </div>
            <div className="absolute top-[40px] left-[1625px] rounded-[50%] bg-gray-200 w-[50px] h-[49px]" />
            <div className="absolute top-[55px] left-[1628px] text-base tracking-[0.1px] leading-[20px] font-medium text-white text-left flex items-center w-[59px] h-4">
              Profile
            </div>
          </div>
        </div>
        <div className="absolute top-[260px] left-[0px] w-[1920px] h-[820px]">
          <div className="absolute top-[0px] left-[0px] bg-white w-[1920px] h-[820px]" />
          <div className="absolute top-[35px] left-[132px] w-[1654.68px] h-[730.87px]">
            <img
              className="absolute top-[0px] left-[0px] w-[737.33px] h-[500px] object-cover"
              alt=""
              src="/group-102@2x.png"
            />
            <div className="absolute top-[0px] left-[846.67px] w-[808.01px] h-[730.87px]">
              <div className="absolute top-[0px] left-[1.33px] text-[42px] text-black inline-block w-[376px]">
                Asgaard sofa
              </div>
              <div className="absolute top-[63px] left-[1.33px] text-5xl font-medium inline-block w-[230.67px]">
                Rs. 250,000.00
              </div>
              <img
                className="absolute top-[114px] left-[0px] w-[165.33px] h-5"
                alt=""
                src="/group-88.svg"
              />
              <div className="absolute top-[108.5px] left-[188.83px] box-border w-px h-[31px] border-r-[1px] border-solid border-darkgray" />
              <div className="absolute top-[114px] left-[218.67px] text-smi inline-block w-[166.67px]">
                5 Customer Review
              </div>
              <div className="absolute top-[152px] left-[0px] text-smi text-black inline-block w-[565.33px] h-20">
                <p className="m-0">
                  Setting the bar as one of the loudest speakers in its class,
                  the Kilburn is a compact, stout-hearted hero with a
                  well-balanced audio which boasts a clear midrange and extended
                  highs for a sound.
                </p>
                <p className="m-0"></p>
              </div>
              <div className="absolute top-[254px] left-[0px] w-[164px] h-[63px] text-smi text-black">
                <div className="absolute top-[0px] left-[0px] text-sm text-darkgray inline-block w-9">
                  Size
                </div>
                <div className="absolute top-[33px] left-[1.33px] w-10 h-[30px]">
                  <div className="absolute top-[0px] left-[0px] rounded-8xs bg-moccasin w-10 h-[30px]" />
                  <div className="absolute top-[5px] left-[16px] inline-block w-2">
                    L
                  </div>
                </div>
                <div className="absolute top-[33px] left-[62.67px] w-10 h-[30px]">
                  <div className="absolute top-[0px] left-[0px] rounded-8xs bg-snow w-10 h-[30px]" />
                  <div className="absolute top-[5px] left-[10.67px] inline-block w-[18.67px]">
                    XL
                  </div>
                </div>
                <div className="absolute top-[33px] left-[124px] w-10 h-[30px]">
                  <div className="absolute top-[0px] left-[0px] rounded-8xs bg-snow w-10 h-[30px]" />
                  <div className="absolute top-[5px] left-[9.33px] inline-block w-[21.33px]">
                    XS
                  </div>
                </div>
              </div>
              <div className="absolute top-[335px] left-[0px] text-sm inline-block w-[50.67px]">
                Color
              </div>
              <div className="absolute top-[368px] left-[1.33px] rounded-31xl bg-mediumslateblue w-10 h-[30px]" />
              <div className="absolute top-[368px] left-[62.67px] rounded-31xl bg-black w-10 h-[30px]" />
              <div className="absolute top-[368px] left-[124px] rounded-31xl bg-darkkhaki w-10 h-[30px]" />
              <div className="absolute top-[430px] left-[1.33px] w-[164px] h-16 text-black">
                <div className="absolute top-[0px] left-[0px] rounded-[10px] bg-white box-border w-[164px] h-16 border-[1px] border-solid border-darkgray" />
                <div className="absolute top-[20px] left-[20px] inline-block w-3">
                  -
                </div>
                <div className="absolute top-[20px] left-[133.33px] inline-block w-[14.67px]">
                  +
                </div>
                <div className="absolute top-[20px] left-[78.67px] font-medium inline-block w-2">
                  1
                </div>
              </div>
              <div className="absolute top-[430px] left-[189.33px] w-[286.67px] h-16 text-xl text-black">
                <div className="absolute top-[0px] left-[0px] rounded-[15px] box-border w-[286.67px] h-16 border-[1px] border-solid border-black bg-orange" />
                {/* <div className="absolute top-[17px] left-[64px] inline-block w-[158.67px]">
                  Add To Cart
                </div> */}
                <button
                  className="absolute top-[17px] left-[64px] inline-block w-[158.67px] text-xl"
                  onClick={addToCartFunction}
                >
                  Add To Cart
                </button>

              </div>
              <img
                className="absolute h-[4.27%] w-[4.13%] top-[95.73%] right-[33.33%] bottom-[0%] left-[62.54%] max-w-full overflow-hidden max-h-full"
                alt=""
                src="/vector.svg"
              />
              <div className="absolute top-[553.5px] left-[0.82px] box-border w-[807.68px] h-px border-t-[1px] border-solid border-gainsboro-200" />
              <div className="absolute top-[595px] left-[0px] inline-block w-10">
                SKU
              </div>
              <div className="absolute top-[595px] left-[142.67px] inline-block w-[58.67px]">
                SS001
              </div>
              <div className="absolute top-[631px] left-[142.67px] inline-block w-[60px]">
                Sofas
              </div>
              <div className="absolute top-[667px] left-[142.67px] inline-block w-[253.33px]">
                Sofa, Chair, Home, Shop
              </div>
              <div className="absolute top-[595px] left-[121.33px] w-[5.33px] h-[132px]">
                <div className="absolute top-[0px] left-[0px] font-medium inline-block w-[5.33px]">
                  :
                </div>
                <div className="absolute top-[36px] left-[0px] font-medium inline-block w-[5.33px]">
                  :
                </div>
                <div className="absolute top-[72px] left-[0px] font-medium inline-block w-[5.33px]">
                  :
                </div>
                <div className="absolute top-[108px] left-[0px] font-medium inline-block w-[5.33px]">
                  :
                </div>
              </div>
              <div className="absolute top-[631px] left-[0px] inline-block w-[100px]">
                Category
              </div>
              <div className="absolute top-[667px] left-[0px] inline-block w-[52px]">
                Tags
              </div>
              <div className="absolute top-[705px] left-[0px] inline-block w-[62.67px]">
                Share
              </div>
              <img
                className="absolute top-[707px] left-[142.67px] w-[26.67px] h-5 overflow-hidden"
                alt=""
                src="/akariconsfacebookfill.svg"
              />
              <img
                className="absolute top-[705px] left-[260px] w-[33.33px] h-[25px] overflow-hidden"
                alt=""
                src="/antdesigntwittercirclefilled.svg"
              />
              <img
                className="absolute top-[707px] left-[202.67px] w-[26.67px] h-5 overflow-hidden"
                alt=""
                src="/akariconslinkedinboxfill.svg"
              />
            </div>
          </div>
        </div>
        <div className="absolute top-[1081px] left-[0px] w-[1920px] h-[744px] text-5xl">
          <div className="absolute top-[0px] left-[0px] bg-white w-[1920px] h-[744px]" />
          <div className="absolute top-[-0.5px] left-[-0.5px] box-border w-[1921px] h-px border-t-[1px] border-solid border-gainsboro-200" />
          <div className="absolute top-[48px] left-[528px] w-[865.33px] h-9">
            <div className="absolute top-[0px] left-[0px] text-black inline-block w-[181.33px]">
              Description
            </div>
            <div className="absolute top-[0px] left-[252px] inline-block w-[358.67px]">
              Additional Information
            </div>
            <div className="absolute top-[0px] left-[681.33px] inline-block w-[184px]">
              Reviews [5]
            </div>
          </div>
          <div className="absolute bottom-[449px] left-[276px] w-[1368px] h-[174px] text-justify text-base">
            <div className="absolute bottom-[126px] left-[0px] inline-block w-[1368px] h-12">
              Embodying the raw, wayward spirit of rock ‘n’ roll, the Kilburn
              portable active stereo speaker takes the unmistakable look and
              sound of Marshall, unplugs the chords, and takes the show on the
              road.
            </div>
            <div className="absolute bottom-[0px] left-[0px] inline-block w-[1368px] h-24">
              Weighing in under 7 pounds, the Kilburn is a lightweight piece of
              vintage styled engineering. Setting the bar as one of the loudest
              speakers in its class, the Kilburn is a compact, stout-hearted
              hero with a well-balanced audio which boasts a clear midrange and
              extended highs for a sound that is both articulate and pronounced.
              The analogue knobs allow you to fine tune the controls to your
              personal preferences while the guitar-influenced leather strap
              enables easy and stylish travel.
            </div>
          </div>
          <img
            className="absolute top-[331px] left-[133.33px] w-[1652px] h-[348px] object-cover"
            alt=""
            src="/group-109@2x.png"
          />
          <div className="absolute top-[743.5px] left-[-0.5px] box-border w-[1921px] h-px border-t-[1px] border-solid border-gainsboro-200" />
        </div>
        <div className="absolute top-[1730px] left-[0px] w-[1920px] h-[777px] text-[36px] text-black">
          <div className="absolute top-[0px] left-[0px] bg-white w-[1920px] h-[777px]" />
          <div className="absolute top-[55px] left-[752px] font-medium inline-block w-[412px]">
            Related Products
          </div>
          <div className="absolute top-[135px] left-[133.33px] w-[1653.33px] h-[397px] text-base">
            <div className="absolute top-[0px] left-[0px] w-[382.67px] h-[372px]">
              <img
                className="absolute top-[0px] left-[0px] w-[382.67px] h-[287px] object-cover"
                alt=""
                src="/mask-group@2x.png"
              />
              <div className="absolute top-[301px] left-[0px] w-[258.67px] h-[71px]">
                <div className="absolute top-[0px] left-[0px] inline-block w-[258.67px]">
                  Trenton modular sofa_3
                </div>
                <div className="absolute top-[35px] left-[0px] text-5xl font-medium inline-block w-[210.67px]">
                  Rs. 25,000.00
                </div>
              </div>
            </div>
            <div className="absolute top-[0px] left-[422.67px] w-[382.67px] h-[397px]">
              <div className="absolute top-[301px] left-[0px] w-[282.67px] h-24">
                <div className="absolute top-[0px] left-[0px] inline-block w-[282.67px]">
                  Granite dining table with dining chair
                </div>
                <div className="absolute top-[60px] left-[0px] text-5xl font-medium inline-block w-[210.67px]">
                  Rs. 25,000.00
                </div>
              </div>
              <img
                className="absolute top-[0px] left-[0px] w-[382.67px] h-[287px] object-cover"
                alt=""
                src="/mask-group1@2x.png"
              />
            </div>
            <div className="absolute top-[0px] left-[846.67px] w-[382.67px] h-[397px]">
              <div className="absolute top-[301px] left-[0px] w-[282.67px] h-24">
                <div className="absolute top-[0px] left-[0px] inline-block w-[282.67px]">
                  Outdoor bar table and stool
                </div>
                <div className="absolute top-[60px] left-[0px] text-5xl font-medium inline-block w-[210.67px]">
                  Rs. 25,000.00
                </div>
              </div>
              <img
                className="absolute top-[0px] left-[0px] w-[382.67px] h-[287px] object-cover"
                alt=""
                src="/mask-group2@2x.png"
              />
            </div>
            <div className="absolute top-[0px] left-[1270.67px] w-[382.67px] h-[397px]">
              <div className="absolute top-[301px] left-[0px] w-[265.33px] h-24">
                <div className="absolute top-[0px] left-[0px] inline-block w-[265.33px]">
                  Plain console with teak mirror
                </div>
                <div className="absolute top-[60px] left-[0px] text-5xl font-medium inline-block w-[210.67px]">
                  Rs. 25,000.00
                </div>
              </div>
              <img
                className="absolute top-[0px] left-[0px] w-[382.67px] h-[287px] object-cover"
                alt=""
                src="/mask-group3@2x.png"
              />
            </div>
          </div>
          <div className="absolute top-[625px] left-[882.67px] w-[153.33px] h-[49px] text-xl">
            <div className="absolute top-[0px] left-[6.67px] font-medium inline-block w-[138.67px]">
              View More
            </div>
            <div className="absolute top-[48px] left-[-1px] box-border w-[155.33px] h-0.5 border-t-[2px] border-solid border-black" />
          </div>
        </div>
        <div className="absolute top-[2497px] left-[-2px] w-[1920px] h-[555px]">
          <div className="absolute top-[0px] left-[0px] bg-white w-[1920px] h-[555px]" />
          <div className="absolute top-[60px] left-[139px] w-[1649.07px] h-[312px]">
            <div className="absolute top-[0px] left-[0px] w-[1492.3px] h-[312px]">
              <div className="absolute top-[108px] left-[0px] inline-block w-[376.04px]">
                <p className="m-0">
                  400 University Drive Suite 200 Coral Gables,
                </p>
                <p className="m-0">FL 33134 USA</p>
              </div>
              <div className="absolute top-[0px] left-[555.49px] w-[936.81px] h-[312px] text-black">
                <div className="absolute top-[0px] left-[0px] w-[464.44px] h-[312px]">
                  <div className="absolute top-[0px] left-[0px] w-[89.72px] h-[312px]">
                    <div className="absolute top-[79px] left-[2.64px] w-[87.08px] h-[233px]">
                      <div className="absolute top-[0px] left-[0px] font-medium inline-block w-[63.33px]">
                        Home
                      </div>
                      <div className="absolute top-[70px] left-[0px] font-medium inline-block w-[55.42px]">
                        Shop
                      </div>
                      <div className="absolute top-[140px] left-[0px] font-medium inline-block w-[64.65px]">
                        About
                      </div>
                      <div className="absolute top-[209px] left-[0px] font-medium inline-block w-[87.08px]">
                        Contact
                      </div>
                    </div>
                    <div className="absolute top-[0px] left-[0px] font-medium text-darkgray inline-block w-[52.78px]">
                      Links
                    </div>
                  </div>
                  <div className="absolute top-[0px] left-[279.72px] w-[184.72px] h-[242px] text-darkgray">
                    <div className="absolute top-[0px] left-[0px] font-medium inline-block w-[48.82px]">
                      Help
                    </div>
                    <div className="absolute top-[79px] left-[0px] w-[184.72px] h-[163px] text-black">
                      <div className="absolute top-[0px] left-[0px] font-medium inline-block w-[184.72px]">
                        Payment Options
                      </div>
                      <div className="absolute top-[70px] left-[0px] font-medium inline-block w-[81.81px]">
                        Returns
                      </div>
                      <div className="absolute top-[139px] left-[0px] font-medium inline-block w-[163.61px]">
                        Privacy Policies
                      </div>
                    </div>
                  </div>
                </div>
                <div className="absolute top-[2px] left-[559.44px] w-[377.37px] h-[101px] text-darkgray">
                  <div className="absolute top-[0px] left-[0px] font-medium inline-block w-[113.47px]">
                    Newsletter
                  </div>
                  <div className="absolute top-[77px] left-[0px] w-[377.37px] h-6 text-sm">
                    <div className="absolute top-[0px] left-[0px] inline-block w-[228.26px]">
                      Enter Your Email Address
                    </div>
                    <div className="absolute top-[23px] left-[-1px] box-border w-[265.89px] h-0.5 border-t-[1px] border-solid border-black" />
                    <div className="absolute top-[0px] left-[278.4px] font-medium text-black inline-block w-[98.96px]">
                      SUBSCRIBE
                    </div>
                    <div className="absolute top-[23px] left-[277.4px] box-border w-[100.97px] h-0.5 border-t-[1px] border-solid border-black" />
                  </div>
                </div>
              </div>
            </div>
            <img
              className="absolute top-[143px] left-[12.94px] w-[1636.13px] h-px"
              alt=""
              src="/group-44.svg"
            />
          </div>
        </div>
        <div className="absolute top-[160px] left-[0px] w-[1920px] h-[100px]">
          <div className="absolute top-[0px] left-[0px] bg-white w-[1920px] h-[100px]" />
          <div className="absolute top-[37px] left-[416px] w-[189.33px] h-[37px] text-black">
            <div className="absolute top-[0px] left-[0px] w-[189.33px] h-[37px]">
              <div className="absolute top-[-1px] left-[-1px] box-border w-0.5 h-[39px] border-r-[2px] border-solid border-darkgray" />
              <div className="absolute top-[6px] left-[45.33px] inline-block w-36">
                Asgaard sofa
              </div>
            </div>
          </div>
          <div className="absolute top-[44px] left-[132px] w-[109.33px] h-6">
            <div className="absolute top-[0px] left-[0px] inline-block w-16">
              Home
            </div>
            <img
              className="absolute top-[2px] left-[82.67px] w-[26.67px] h-5 overflow-hidden"
              alt=""
              src="/dashiconsarrowupalt2.svg"
            />
          </div>
          <div className="absolute top-[44px] left-[273.33px] w-[109.33px] h-6">
            <div className="absolute top-[0px] left-[0px] inline-block w-[54.67px]">
              Shop
            </div>
            <img
              className="absolute top-[2px] left-[82.67px] w-[26.67px] h-5 overflow-hidden"
              alt=""
              src="/dashiconsarrowupalt21.svg"
            />
          </div>
        </div>
        <b className="absolute top-[519px] left-[1023px] text-smi inline-block text-black w-[139px] h-4">
          Earn 250 Tokens
        </b>
      </div>
      <div className="absolute top-[14px] left-[calc(50%_-_60px)] bg-gray-400 shadow-[0px_3px_16px_rgba(0,_0,_0,_0.11)] w-[120px] h-10 text-center text-sm text-royalblue">
        <img
          className="absolute top-[16.5px] left-[calc(50%_-_45.14px)] w-[11px] h-1.5 overflow-hidden"
          alt=""
          src="/svg5.svg"
        />
        <div className="absolute top-[12px] left-[33.36px] leading-[19.6px] font-medium flex items-center justify-center w-[70.76px] h-4">
          Back to top
        </div>
      </div>
      <div className="absolute w-full top-[0px] right-[-1px] left-[1px] bg-royalblue h-14 text-white">
        <div className="absolute h-full top-[0px] bottom-[0px] left-[calc(50%_-_624px)] w-[1248px]">
          <div className="absolute top-[0px] right-[1111px] w-[75px] h-14 text-[11px] text-whitesmoke-200">
            <div className="absolute top-[calc(50%_+_1.86px)] left-[0px] w-[75px] h-[15.39px]">
              <img
                className="absolute top-[1px] left-[61.39px] w-2.5 h-2.5 object-cover"
                alt=""
                src="/plus-aef861png@2x.png"
              />
            </div>
            <div className="absolute top-[14px] left-[1px] text-sm text-white flex items-center w-[73px] h-3.5">
              FLIPCART
            </div>
          </div>
          <div className="absolute w-[calc(100%_-_684px)] top-[calc(50%_-_18px)] right-[535px] left-[149px] bg-gray-400 shadow-[0px_2px_4px_rgba(0,_0,_0,_0.23)] h-9 text-sm text-gray-100">
            <div className="absolute w-full top-[0px] right-[0px] left-[0px] rounded-sm bg-white h-9">
              <img
                className="absolute top-[0px] left-[521.66px] rounded-sm w-[42.34px] h-9"
                alt=""
                src="/button.svg"
              />
              <div className="absolute w-[calc(100%_-_42.34px)] top-[0px] right-[42.34px] left-[0px] rounded-tl-sm rounded-tr-none rounded-br-none rounded-bl-sm bg-white h-9">
                <div className="absolute top-[10px] left-[16px] w-[489.66px] h-4 overflow-hidden">
                  <div className="absolute top-[0px] left-[0px] flex items-center w-[234.47px] h-4">
                    Search for products, brands and more
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="absolute top-[12px] left-[759.69px] rounded-sm bg-white flex flex-row pt-1.5 pb-[5px] pr-[39.5px] pl-[41px] items-start justify-start text-royalblue border-[1px] border-solid border-gainsboro-100">
            <div className="relative tracking-[0.1px] leading-[20px] font-medium">
              Login
            </div>
          </div>
          <div className="absolute top-[18px] left-[921.19px] tracking-[0.1px] leading-[20px] font-medium flex items-center w-[117.4px] h-[19px]">
            Become a Seller
          </div>
          <div className="absolute h-full top-[0px] right-[102px] bottom-[0px] w-[70px]">
            <img
              className="absolute top-[calc(50%_-_1.85px)] left-[43.17px] w-2 h-[4.69px] overflow-hidden"
              alt=""
              src="/svg6.svg"
            />
            <div className="absolute top-[12px] left-[-3px] overflow-hidden flex flex-row items-start justify-start">
              <div className="relative tracking-[0.1px] leading-[20px] font-medium flex items-center w-[42px] h-[29px] shrink-0">
                More
              </div>
            </div>
          </div>
          <div className="absolute top-[0px] left-[1165.77px] flex flex-row py-[18px] pr-0 pl-2 items-center justify-start gap-[8px]">
            <img
              className="relative w-4 h-4 overflow-hidden shrink-0"
              alt=""
              src="/svg7.svg"
            />
            <div className="relative tracking-[0.1px] leading-[20px] font-medium">
              Cart
            </div>
          </div>
        </div>
      </div>
      <img
        className="absolute top-[513px] left-[983px] rounded-31xl w-8 h-8 object-cover"
        alt=""
        src="/image-1@2x.png"
      />
    </div>
  );
};

export default Flipkart;
