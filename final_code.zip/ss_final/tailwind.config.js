/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        whitesmoke: {
          "100": "#f1f3f6",
          "200": "#f0f0f0",
        },
        royalblue: "#2874f0",
        white: "#fff",
        gainsboro: {
          "100": "#dbdbdb",
          "200": "#d9d9d9",
        },
        gray: {
          "100": "#757575",
          "200": "#2b1f34",
          "300": "#212121",
          "400": "rgba(255, 255, 255, 0)",
        },
        black: "#000",
        darkgray: "#9f9f9f",
        darkkhaki: "#cdba7b",
        mediumslateblue: "#816dfa",
        snow: "#faf4f4",
        moccasin: "#fbebb5",
      },
      fontFamily: {
        roboto: "Roboto",
        poppins: "Poppins",
      },
      borderRadius: {
        "31xl": "50px",
        "8xs": "5px",
      },
    },
    fontSize: {
      base: "16px",
      sm: "14px",
      smi: "13px",
      xl: "20px",
      "5xl": "24px",
      inherit: "inherit",
    },
  },
  corePlugins: {
    preflight: false,
  },
};
